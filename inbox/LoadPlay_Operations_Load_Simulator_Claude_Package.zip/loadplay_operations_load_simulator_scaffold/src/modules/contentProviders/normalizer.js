import { allowedLicensePolicy } from './providerRegistry.js';

export function normalizeImportedItem(raw, provider) {
  const license = raw.license || raw.licenseUrl || 'Unknown';
  const normalized = {
    provider,
    providerId: raw.id || raw.identifier || raw.pageid || raw.guid || crypto.randomUUID(),
    sourceUrl: raw.sourceUrl || raw.url || raw.webformatURL || raw.foreign_landing_url || '',
    mediaUrl: raw.mediaUrl || raw.fileUrl || raw.videos?.medium?.url || raw.previewURL || '',
    thumbnailUrl: raw.thumbnailUrl || raw.thumbnail || raw.previewURL || raw.image || '',
    title: raw.title || raw.name || 'Untitled imported item',
    description: raw.description || raw.summary || '',
    creator: raw.creator || raw.author || raw.user || 'Unknown creator',
    license,
    licenseUrl: raw.licenseUrl || raw.license_url || '',
    attributionText: buildAttribution(raw, provider),
    mediaType: raw.mediaType || raw.type || 'unknown',
    duration: raw.duration || null,
    category: raw.category || 'Draft Import',
    tags: raw.tags || [],
    dateDiscovered: new Date().toISOString(),
    status: statusForLicense(license),
    approvedByAdmin: false,
    rightsNotes: '',
    simulationOnly: false
  };
  return normalized;
}

function buildAttribution(raw, provider) {
  const creator = raw.creator || raw.author || raw.user || 'Unknown creator';
  const title = raw.title || raw.name || 'Untitled';
  return `${title} by ${creator}, via ${provider}`;
}

function statusForLicense(license) {
  if (allowedLicensePolicy.autoApprove.some(x => license.includes(x))) return 'draft';
  return 'rights_review';
}
