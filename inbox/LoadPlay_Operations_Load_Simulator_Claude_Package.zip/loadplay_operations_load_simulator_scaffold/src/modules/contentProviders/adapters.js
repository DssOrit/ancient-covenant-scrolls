import { normalizeImportedItem } from './normalizer.js';

export async function fetchInternetArchive(query = 'mediatype:(movies) AND collection:(feature_films)') {
  const url = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(query)}&fl[]=identifier&fl[]=title&fl[]=description&fl[]=creator&fl[]=date&fl[]=licenseurl&rows=25&page=1&output=json`;
  const data = await fetchJson(url);
  return (data.response?.docs || []).map(item => normalizeImportedItem({
    ...item,
    id: item.identifier,
    sourceUrl: `https://archive.org/details/${item.identifier}`,
    mediaType: 'video',
    license: item.licenseurl || 'Unknown'
  }, 'Internet Archive'));
}

export async function fetchPexels(query = 'cinematic background', apiKey) {
  if (!apiKey) return demoPreview('Pexels');
  const url = `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=20`;
  const data = await fetchJson(url, { headers: { Authorization: apiKey } });
  return (data.photos || []).map(photo => normalizeImportedItem({
    id: photo.id,
    title: photo.alt,
    creator: photo.photographer,
    sourceUrl: photo.url,
    mediaUrl: photo.src?.large,
    thumbnailUrl: photo.src?.medium,
    license: 'Pexels License',
    mediaType: 'image'
  }, 'Pexels'));
}

export async function fetchPixabay(query = 'documentary', apiKey) {
  if (!apiKey) return demoPreview('Pixabay');
  const url = `https://pixabay.com/api/?key=${encodeURIComponent(apiKey)}&q=${encodeURIComponent(query)}&image_type=photo&per_page=20&safesearch=true`;
  const data = await fetchJson(url);
  return (data.hits || []).map(hit => normalizeImportedItem({
    id: hit.id,
    title: hit.tags,
    creator: hit.user,
    sourceUrl: hit.pageURL,
    mediaUrl: hit.largeImageURL,
    thumbnailUrl: hit.previewURL,
    license: 'Pixabay Content License',
    mediaType: 'image',
    tags: String(hit.tags || '').split(',').map(t => t.trim())
  }, 'Pixabay'));
}

export async function fetchNasa(queryDate, apiKey = 'DEMO_KEY') {
  const dateParam = queryDate ? `&date=${queryDate}` : '';
  const url = `https://api.nasa.gov/planetary/apod?api_key=${encodeURIComponent(apiKey)}${dateParam}`;
  const item = await fetchJson(url);
  return [normalizeImportedItem({
    id: item.date,
    title: item.title,
    description: item.explanation,
    sourceUrl: item.hdurl || item.url,
    mediaUrl: item.hdurl || item.url,
    thumbnailUrl: item.thumbnail_url || item.url,
    creator: item.copyright || 'NASA',
    license: item.copyright ? 'Unknown' : 'NASA public media, verify item',
    mediaType: item.media_type
  }, 'NASA Open APIs')];
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) throw new Error(`Provider request failed: ${response.status}`);
  return response.json();
}

function demoPreview(provider) {
  return [{
    provider,
    providerId: `demo_${provider.toLowerCase().replace(/\s+/g, '_')}`,
    title: `${provider} Demo Preview Only`,
    description: 'Demo item shown because API key is missing. Not publishable.',
    sourceUrl: '',
    mediaUrl: '',
    thumbnailUrl: '',
    creator: 'Demo Generator',
    license: 'Demo Only',
    status: 'demo_preview_only',
    approvedByAdmin: false,
    dateDiscovered: new Date().toISOString(),
    simulationOnly: true
  }];
}
