export const providerRegistry = [
  { id: 'internet_archive', name: 'Internet Archive', requiresKey: false, type: 'archive_video_audio_books' },
  { id: 'openverse', name: 'Openverse', requiresKey: false, type: 'open_media_discovery' },
  { id: 'pexels', name: 'Pexels', requiresKey: true, keyName: 'PEXELS_API_KEY', type: 'photos_videos' },
  { id: 'pixabay', name: 'Pixabay', requiresKey: true, keyName: 'PIXABAY_API_KEY', type: 'images_videos_music_sfx' },
  { id: 'wikimedia', name: 'Wikimedia Commons', requiresKey: false, type: 'educational_media' },
  { id: 'freesound', name: 'Freesound', requiresKey: true, keyName: 'FREESOUND_API_KEY', type: 'sound_effects' },
  { id: 'jamendo', name: 'Jamendo', requiresKey: true, keyName: 'JAMENDO_CLIENT_ID', type: 'music_discovery' },
  { id: 'gdelt', name: 'GDELT', requiresKey: false, type: 'news_research_metadata' },
  { id: 'nasa', name: 'NASA Open APIs', requiresKey: true, keyName: 'NASA_API_KEY', type: 'science_space' },
  { id: 'nps', name: 'National Park Service API', requiresKey: true, keyName: 'NPS_API_KEY', type: 'nature_history_places' },
  { id: 'rss', name: 'RSS Feed Importer', requiresKey: false, type: 'approved_feed_metadata' }
];

export const allowedLicensePolicy = {
  autoApprove: ['Public Domain', 'CC0', 'CC BY'],
  manualReview: ['CC BY-SA', 'CC BY-NC', 'Custom License', 'Unknown'],
  blockedByDefault: ['All Rights Reserved', 'No License Found']
};
