export const workloadRules = {
  viewer_signup: { minutes: 0, requiresHuman: false, department: 'Viewer Activity', priority: 'low' },
  viewer_login: { minutes: 0, requiresHuman: false, department: 'Viewer Activity', priority: 'low' },
  watch_session: { minutes: 0, requiresHuman: false, department: 'Viewer Activity', priority: 'low' },
  like: { minutes: 0, requiresHuman: false, department: 'Engagement', priority: 'low' },
  save_to_my_list: { minutes: 0, requiresHuman: false, department: 'Engagement', priority: 'low' },
  search_activity: { minutes: 0, requiresHuman: false, department: 'Engagement', priority: 'low' },
  comment: { minutes: 2, requiresHuman: true, department: 'Moderation', priority: 'medium' },
  content_report: { minutes: 10, requiresHuman: true, department: 'Moderation', priority: 'high' },
  content_upload: { minutes: 8, requiresHuman: true, department: 'Content Review', priority: 'medium' },
  failed_upload: { minutes: 10, requiresHuman: true, department: 'Technical Support', priority: 'medium' },
  creator_application: { minutes: 12, requiresHuman: true, department: 'Creator Success', priority: 'medium' },
  rights_review: { minutes: 12, requiresHuman: true, department: 'Rights Review', priority: 'high' },
  api_content_discovered: { minutes: 4, requiresHuman: true, department: 'Content Curation', priority: 'medium' },
  homepage_row_update: { minutes: 7, requiresHuman: true, department: 'Programming', priority: 'medium' },
  support_ticket: { minutes: 9, requiresHuman: true, department: 'Support', priority: 'high' },
  broken_media_link: { minutes: 11, requiresHuman: true, department: 'Technical Support', priority: 'high' },
  flagged_content: { minutes: 15, requiresHuman: true, department: 'Safety Review', priority: 'urgent' }
};

export function estimateEventMinutes(type) {
  return workloadRules[type]?.minutes ?? 5;
}

export function getRule(type) {
  return workloadRules[type] || { minutes: 5, requiresHuman: true, department: 'Admin', priority: 'medium' };
}
