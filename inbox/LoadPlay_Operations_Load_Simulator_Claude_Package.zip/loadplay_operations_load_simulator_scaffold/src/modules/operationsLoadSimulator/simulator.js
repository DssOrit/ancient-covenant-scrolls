import { faker } from '@faker-js/faker';
import { db } from './db.js';
import { scenarios } from './scenarios.js';
import { getRule } from './workloadRules.js';

function createEvent(type, scenarioKey) {
  const rule = getRule(type);
  return {
    eventId: `sim_${crypto.randomUUID()}`,
    scenarioKey,
    type,
    category: rule.department,
    priority: rule.priority,
    status: rule.requiresHuman ? 'pending' : 'auto_recorded',
    estimatedMinutes: rule.minutes,
    requiresHuman: rule.requiresHuman,
    createdAt: faker.date.recent({ days: 1 }).toISOString(),
    assignedDepartment: rule.department,
    title: buildTitle(type),
    simulationOnly: true,
    label: 'SIMULATION ONLY'
  };
}

function buildTitle(type) {
  const titles = {
    viewer_signup: 'New viewer account created',
    watch_session: 'Viewer watch session recorded',
    like: 'Viewer liked content',
    save_to_my_list: 'Viewer saved item to My List',
    comment: 'Viewer comment needs moderation sample',
    content_report: 'Viewer reported content',
    content_upload: 'Creator uploaded content for review',
    failed_upload: 'Upload failed and needs support',
    creator_application: 'Creator application submitted',
    rights_review: 'Rights review item created',
    api_content_discovered: 'Provider discovered new content candidate',
    homepage_row_update: 'Homepage row decision needed',
    support_ticket: 'Support ticket opened',
    broken_media_link: 'Broken media link detected',
    flagged_content: 'Flagged content requires urgent review'
  };
  return titles[type] || `Simulated ${type}`;
}

export async function runScenario(scenarioKey) {
  const scenario = scenarios[scenarioKey];
  if (!scenario) throw new Error(`Unknown scenario: ${scenarioKey}`);
  const events = [];
  Object.entries(scenario.counts).forEach(([type, count]) => {
    for (let i = 0; i < count; i += 1) events.push(createEvent(type, scenarioKey));
  });
  await db.simulatedEvents.bulkAdd(events);
  const report = calculateReport(events, scenarioKey);
  await db.operationReports.add(report);
  return report;
}

export function calculateReport(events, scenarioKey, staffHoursAvailable = 4) {
  const humanEvents = events.filter(e => e.requiresHuman);
  const totalMinutes = humanEvents.reduce((sum, e) => sum + e.estimatedMinutes, 0);
  const staffMinutes = staffHoursAvailable * 60;
  const overflowMinutes = Math.max(0, totalMinutes - staffMinutes);
  const byDepartment = {};
  for (const event of humanEvents) {
    byDepartment[event.assignedDepartment] ??= { count: 0, minutes: 0 };
    byDepartment[event.assignedDepartment].count += 1;
    byDepartment[event.assignedDepartment].minutes += event.estimatedMinutes;
  }
  return {
    createdAt: new Date().toISOString(),
    scenario: scenarioKey,
    totalEvents: events.length,
    humanTasks: humanEvents.length,
    totalStaffMinutesNeeded: totalMinutes,
    totalStaffHoursNeeded: round(totalMinutes / 60),
    staffHoursAvailable,
    overflowHours: round(overflowMinutes / 60),
    riskLevel: riskLevel(totalMinutes, staffMinutes),
    byDepartment,
    recommendations: buildRecommendations(byDepartment, overflowMinutes),
    simulationOnly: true
  };
}

function riskLevel(totalMinutes, staffMinutes) {
  if (totalMinutes <= staffMinutes * 0.75) return 'manageable';
  if (totalMinutes <= staffMinutes) return 'near_capacity';
  if (totalMinutes <= staffMinutes * 1.8) return 'overloaded';
  return 'critical';
}

function buildRecommendations(byDepartment, overflowMinutes) {
  const output = [];
  if (overflowMinutes > 0) output.push('Delay nonessential publishing decisions and batch low-risk reviews.');
  if ((byDepartment['Rights Review']?.minutes || 0) > 180) output.push('Add rights review caps and fast-track only public domain, CC0, and approved internal originals.');
  if ((byDepartment['Support']?.minutes || 0) > 120) output.push('Add help center auto-responses for common login, playback, and upload issues.');
  if ((byDepartment['Content Review']?.minutes || 0) > 180) output.push('Require complete metadata before submission and limit creator uploads during pilot.');
  if ((byDepartment['Content Curation']?.minutes || 0) > 120) output.push('Cap provider imports per day and send unknown licenses to manual review only.');
  if (!output.length) output.push('Workload appears manageable. Keep monitoring queue pressure.');
  return output;
}

function round(value) {
  return Math.round(value * 10) / 10;
}
