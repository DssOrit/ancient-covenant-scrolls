export const scenarios = {
  light_day: {
    label: 'Light Activity Day',
    counts: { viewer_signup: 15, watch_session: 90, like: 18, save_to_my_list: 10, content_upload: 3, support_ticket: 2, rights_review: 4, api_content_discovered: 8 }
  },
  normal_day: {
    label: 'Normal Activity Day',
    counts: { viewer_signup: 40, watch_session: 260, like: 70, save_to_my_list: 35, content_upload: 9, support_ticket: 7, rights_review: 12, api_content_discovered: 25, homepage_row_update: 4 }
  },
  busy_day: {
    label: 'Busy Activity Day',
    counts: { viewer_signup: 120, watch_session: 850, like: 210, save_to_my_list: 130, content_upload: 28, support_ticket: 18, rights_review: 36, api_content_discovered: 70, content_report: 9, broken_media_link: 4 }
  },
  viral_spike: {
    label: 'Viral Spike',
    counts: { viewer_signup: 900, watch_session: 9000, like: 2800, save_to_my_list: 1100, comment: 400, content_report: 70, support_ticket: 80, broken_media_link: 14, homepage_row_update: 12 }
  },
  creator_upload_rush: {
    label: 'Creator Upload Rush',
    counts: { creator_application: 45, content_upload: 120, failed_upload: 30, rights_review: 100, support_ticket: 35, homepage_row_update: 10 }
  },
  api_content_flood: {
    label: 'API Content Flood',
    counts: { api_content_discovered: 250, rights_review: 140, homepage_row_update: 15, support_ticket: 6 }
  },
  one_person_day: {
    label: 'One-Person Operation',
    counts: { viewer_signup: 35, watch_session: 225, content_upload: 8, rights_review: 10, support_ticket: 6, api_content_discovered: 20, homepage_row_update: 2, content_report: 3 }
  }
};
