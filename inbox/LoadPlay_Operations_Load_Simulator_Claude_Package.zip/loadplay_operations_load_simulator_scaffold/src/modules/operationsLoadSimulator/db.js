import Dexie from 'dexie';

export const db = new Dexie('LoadPlayOperationsPilotDB');

db.version(1).stores({
  simulatorSettings: 'key',
  simulatedEvents: '++id,eventId,type,category,status,priority,createdAt,simulationOnly',
  simulatedQueues: '++id,queueId,department,status,severity,createdAt',
  staffProfiles: '++id,role,hoursPerDay,active',
  providerDrafts: '++id,provider,providerId,status,license,mediaType,dateDiscovered',
  operationReports: '++id,createdAt,scenario,riskLevel'
});

export async function resetSimulationData() {
  await db.simulatedEvents.clear();
  await db.simulatedQueues.clear();
  await db.operationReports.clear();
}
