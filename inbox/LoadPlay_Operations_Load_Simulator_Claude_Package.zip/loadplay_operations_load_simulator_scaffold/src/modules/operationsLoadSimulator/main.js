import { runScenario } from './simulator.js';
import { resetSimulationData } from './db.js';
import { downloadJson, downloadCsv } from './reportExport.js';

let lastReport = null;

document.addEventListener('click', async event => {
  const scenario = event.target?.dataset?.scenario;
  if (scenario) {
    lastReport = await runScenario(scenario);
    renderReport(lastReport);
  }
  if (event.target?.id === 'exportOpsJson' && lastReport) downloadJson('loadplay-operations-report.json', lastReport);
  if (event.target?.id === 'exportOpsCsv' && lastReport) downloadCsv('loadplay-operations-report.csv', flattenReport(lastReport));
  if (event.target?.id === 'resetOpsSimulation') {
    await resetSimulationData();
    lastReport = null;
    renderEmpty();
  }
});

function renderReport(report) {
  const metrics = document.getElementById('operationsMetrics');
  metrics.innerHTML = `
    <div class="metric-card">Total simulated events<strong>${report.totalEvents}</strong></div>
    <div class="metric-card">Human tasks<strong>${report.humanTasks}</strong></div>
    <div class="metric-card">Staff hours needed<strong>${report.totalStaffHoursNeeded}</strong></div>
    <div class="metric-card">Overflow hours<strong>${report.overflowHours}</strong></div>
    <div class="metric-card">Risk level<strong>${report.riskLevel}</strong></div>
  `;
  document.getElementById('recommendations').innerHTML = report.recommendations.map(r => `<p>${r}</p>`).join('');
  document.getElementById('bottleneckAlerts').innerHTML = Object.entries(report.byDepartment)
    .sort((a,b) => b[1].minutes - a[1].minutes)
    .map(([department, data]) => `<p><strong>${department}</strong>: ${data.count} tasks, ${Math.round(data.minutes / 60 * 10) / 10} hours</p>`)
    .join('');
}

function renderEmpty() {
  document.getElementById('operationsMetrics').innerHTML = '';
  document.getElementById('recommendations').innerHTML = '';
  document.getElementById('bottleneckAlerts').innerHTML = '';
}

function flattenReport(report) {
  return Object.entries(report.byDepartment).map(([department, data]) => ({
    scenario: report.scenario,
    riskLevel: report.riskLevel,
    department,
    taskCount: data.count,
    minutes: data.minutes,
    hours: Math.round(data.minutes / 60 * 10) / 10
  }));
}
