# Load Main Site Evaluation and Claude Handoff Report

Prepared for: Claude developer handoff  
Project: Load Main PWA  
Live site reviewed: https://dssorit.github.io/ancient-covenant-scrolls/load/  
Report date: 2026-05-06  
Purpose: Bring Load Main into alignment with the locked master Load ecosystem plan without false-positive completion claims.

---

## 1. Executive Summary

Load Main is a strong foundation, but it is not yet the complete master-build version.

The live site already presents Load as an iPad-first PWA workspace with Library, Import, Create New, reading tools, TTS, Piper diagnostics, Developer Console, Load AI provider chain, backup/restore language, media support, and links to LoadPlay and LoadStudio.

The main gap is not branding. The main gap is operational completion.

The current site still needs:

1. A visible one-click standalone PWA ZIP builder.
2. Full security scanning before ZIP download.
3. Export receipts after every build/export.
4. Feature Verification Dashboard with pass/fail/warning/not-tested reporting.
5. LoadStudio package validation for `.loadstudio.zip` and `.cinepwa.zip`.
6. Rights metadata validation before LoadPlay publishing or package preparation.
7. Safer sandbox preview defaults for untrusted HTML/PWA imports.
8. Cleanup of contradictory AI, offline, and privacy wording.
9. Removal or replacement of prohibited reading-accessibility terms in user-facing UI.
10. Clear routing actions between Load Main, LoadStudio, and LoadPlay.

Estimated alignment with the Load Main master plan: 55% to 60%.

---

## 2. Evidence From Live Site Review

### 2.1 Present and working as visible UI or copy

The live page visibly includes:

- Load branding.
- “Run Web Apps on iPad.”
- Installable app messaging.
- Home, Library, Import, Create New, Get Started, and Open Library navigation.
- Workspace shortcuts.
- Library empty state.
- Import flow for HTML, ZIP/PWA, PDF, EPUB, DOCX, TXT, Markdown, images, audio, and video.
- iPad workaround instructions for PWA folder import.
- Create New templates.
- PWA Reader Book template.
- Reading tools.
- Notes.
- Bookmarks.
- Browser TTS.
- Piper install, repair, skip, and diagnostics.
- Load AI provider settings.
- Developer Console.
- Scan current page.
- Auto-fix issues.
- Backup and restore copy.
- Links to LoadPlay and LoadStudio.

The site states it can import HTML, ZIP, PDF, EPUB, manuscript files, and media, then preview, diagnose, fix, and export standalone HTML, PWA ZIP, PDF, EPUB, and MP4.

### 2.2 Present but not fully verified from visible site alone

These features are described or implied, but must not be marked complete until Claude verifies them in code and UI:

- PWA ZIP export.
- Standalone HTML export.
- EPUB export.
- PDF export.
- MP4 export.
- Manifest repair.
- Service worker generation.
- Asset Doctor repairs.
- Auto-fix applying fixes safely.
- Imported ZIP/PWA project stitching.
- Library backup export and import.
- Piper generation and playback.
- Provider fallback routing.
- Add specific imported app to Home Screen.
- Media editing.
- Book-to-video scene cards.
- App Package export.

The current site copy mentions these capabilities, but the handoff requirement is strict: do not mark them complete unless the UI can run and report a real test.

---

## 3. Major Issues Requiring Fix

### 3.1 AI and privacy copy contradictions

The site contains conflicting claims:

- It says the core app is local-first and optional cloud AI providers only run when enabled.
- It also says no network and that nothing goes to the internet.
- It also says Load is currently zero-AI, while another section describes Load AI as a built-in assistant and provider chain.

Required fix:

Replace contradictory language with this unified truth:

```text
Load’s core workspace is local-first. Imported files, notes, bookmarks, and settings are stored on this device where browser support allows. Load includes a built-in local helper for app guidance and slash commands. Optional cloud AI providers only run when the user enables them and may send the selected prompt or asset to the provider chosen by the user.
```

Do not say “zero-AI” while Load AI exists.  
Do not say “no network” without clarifying that optional online features may connect when enabled.

### 3.2 Prohibited reading-accessibility wording still appears in user-facing UI

The user specifically does not want the following terms displayed anywhere in the site interface:

```text
dyslexic
dyslexia
```

Replace with:

```text
readability-friendly
focus-friendly
accessible reading
reading support font
plain-language reading tools
```

Important:
Do not remove the feature. Only change the displayed wording.

### 3.3 Sandbox preview is too permissive for untrusted packages

The site currently describes iframe behavior using broad permissions such as:

```html
allow-scripts allow-same-origin allow-forms allow-popups
```

That is not appropriate as the default for untrusted imported HTML or PWA packages.

Required default for untrusted preview:

```html
<iframe sandbox="allow-scripts" referrerpolicy="no-referrer"></iframe>
```

Only enable `allow-same-origin`, `allow-forms`, or `allow-popups` after the user marks the package as trusted.

### 3.4 Missing one-click standalone PWA ZIP builder

The master plan requires a visible one-click build flow.

Required button:

```text
Build Standalone PWA ZIP
```

This button must produce a real ZIP Blob/File and must not show success unless a real file exists.

The builder must create or repair:

```text
index.html
manifest.json
service-worker.js
styles.css
app.js
project-data.json or book-data.json or chapters.json
assets/icons/icon-192.png
assets/icons/icon-512.png
assets/images/
README.md
export-receipt.json
security-report.json
```

### 3.5 Missing pre-download security scan

Every generated ZIP must be scanned before download.

Block export by default for:

- Executable files.
- Hidden `.env` files.
- Hard-coded API keys.
- Credential capture forms.
- Malicious redirects.
- Path traversal such as `../`.
- Unsafe service worker network hijacking patterns.
- Dangerous external scripts.
- Unknown executable payloads.

Warn for:

- Large images.
- Missing optional icons.
- Non-critical external links.
- Incomplete metadata.
- Partial offline cache.

### 3.6 Missing export receipts

After every export, generate a visible receipt.

Required receipt fields:

```text
export type
file name
file size
created date/time
included files
missing files
warnings
manifest status
service worker status
rights status
offline status
safety status
next recommended action
```

Required receipt actions:

```text
Download Receipt
Copy Receipt
Save Receipt to Library
```

### 3.7 Missing LoadStudio package validator

Load Main must recognize and validate:

```text
.loadstudio.zip
.cinepwa.zip
```

Required LoadStudio package files:

```text
index.html
manifest.json
service-worker.js
project.json
scenes.json
characters.json
rights.json
credits.json
styles.css
player.js
editor.js
```

Required folders:

```text
assets/images/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
assets/icons/
```

Required actions:

```text
Open as Viewer
Open as Editable Project
Validate Package
Repair Package
Export Fixed Package
Prepare for LoadStudio
Prepare for LoadPlay
```

### 3.8 Missing rights metadata validator

The master plan requires rights metadata before publishing or platform preparation.

Required `rights.json` fields:

```text
owner
license
sourceMaterial
assetDeclarations
notes or creator confirmation
```

Supported rights values:

```text
user-owned
public-domain
licensed
platform-original
user-generated
user-recorded
third-party-licensed
unknown
```

If `unknown` appears, show a warning and block LoadPlay publish-prep until resolved.

### 3.9 Missing Feature Verification Dashboard

The Developer Console exists, but the master plan needs a broader Feature Verification Dashboard with a Run All Tests button and exportable reports.

Each test must return:

```text
PASS
FAIL
WARNING
NOT TESTED
```

Each result must include:

```text
short user-readable explanation
technical detail
suggested fix
timestamp
```

Required dashboard buttons:

```text
Run All Tests
Export Diagnostic Report
Copy Report
Clear Report
```

---

## 4. Current Scorecard

| Area | Status | Notes |
|---|---:|---|
| Load branding and app identity | Strong | Brand and core promise are clear |
| Installable PWA copy | Present | Needs truth cleanup around offline and network |
| Library | Present | Needs functional tests |
| Import HTML/PWA/PDF/EPUB/media | Present | Needs pass/fail tests |
| Create New templates | Present | PWA Reader included |
| Reading tools | Present | Needs wording cleanup |
| TTS | Present | Browser TTS visible |
| Piper diagnostics | Present | Good foundation |
| Load AI provider chain | Partly aligned | Contradictory copy remains |
| Developer Console | Present | Needs broader dashboard |
| Feature Verification Dashboard | Missing | Must be added |
| One-click PWA ZIP builder | Missing or not visible | Must be explicit |
| Security scan before export | Missing or incomplete | Must be enforced |
| Export receipts | Missing | Required |
| LoadStudio package validator | Missing | Required |
| Rights metadata validator | Missing | Required |
| LoadPlay publish-prep | Missing or not visible | Required |
| Safer sandbox preview | Incomplete | Default is too permissive |
| Sample test projects | Missing or not visible | Required |
| User-facing wording cleanup | Failed | Must be patched |

---

## 5. Required Build Patch for Claude

### TASK: Load Main Master Plan Completion Patch

Do not rebuild the whole site. Patch only the files required.

Do not give a false-positive completion report. Only mark a feature complete if it is visibly working, testable in the UI, and backed by a real pass/fail result.

Goal:
Bring Load Main closer to the master plan by adding the missing one-click PWA ZIP builder, security scanning, export receipts, LoadStudio package validation, rights metadata validation, safer sandbox preview, Feature Verification Dashboard, and copy cleanup.

---

## 6. Part A: Copy Cleanup

### A1. Remove prohibited reading-accessibility terms

Remove all user-facing instances of:

```text
dyslexic
dyslexia
```

Replace with context-appropriate wording:

```text
readability-friendly
focus-friendly
accessible reading
reading support font
plain-language reading tools
```

Examples:

```text
Dyslexia font toggle
```

Becomes:

```text
Readability-friendly font toggle
```

```text
Many dyslexic readers find it easier.
```

Becomes:

```text
Many readers find this easier for focus and visual comfort.
```

### A2. Fix AI and privacy contradictions

Use this canonical wording:

```text
Load’s core workspace is local-first. Imported files, notes, bookmarks, and settings are stored on this device where browser support allows. Load includes a built-in local helper for app guidance and slash commands. Optional cloud AI providers only run when the user enables them and may send the selected prompt or asset to the provider chosen by the user.
```

Replace all unqualified claims such as:

```text
No network
Nothing goes to the internet
Load never uses the internet after the first visit
Load is currently zero-AI
```

With qualified truthful copy.

---

## 7. Part B: Feature Verification Dashboard

Create a visible Feature Verification Dashboard.

Preferred location:
Developer Console, or a dedicated Diagnostics screen accessible from the top toolbar or Workspace section.

Required buttons:

```text
Run All Tests
Export Diagnostic Report
Copy Report
Clear Report
```

Required result format:

```js
const diagnosticResult = {
  id: "manifest_check",
  label: "Manifest Check",
  status: "PASS",
  explanation: "manifest.json exists and includes required fields.",
  technicalDetail: {},
  suggestedFix: "",
  timestamp: new Date().toISOString()
};
```

Required tests:

```text
1. App loads as standalone PWA
2. manifest.json found
3. manifest has app name, icons, theme color, display mode
4. service-worker.js found
5. service worker registers successfully
6. offline cache test passes
7. IndexedDB available
8. localStorage available
9. import HTML works
10. import ZIP/PWA works
11. import PDF works
12. import EPUB works
13. import DOCX works
14. import TXT works
15. import Markdown works
16. import image works
17. import audio works
18. import video works
19. media playback works
20. file saved to library
21. file reopened from library
22. backup export works
23. backup import works
24. standalone HTML export works
25. PWA ZIP export works
26. manifest repair works
27. service worker generation works
28. asset doctor detects missing assets
29. external URL detector works
30. JavaScript error capture works
31. auto-fix returns clear report
32. browser TTS voice works
33. Piper raw audio test works
34. Piper generation test works
35. Piper playback test works
36. Load AI built-in helper works
37. optional AI provider key validation works
38. optional AI provider fallback works
39. LoadStudio package validator works
40. LoadPlay publish-prep validator works
41. sandbox preview works
42. rights metadata validator works
43. export receipt is generated
44. one-click standalone PWA ZIP builder creates a real ZIP
45. security scan blocks unsafe ZIP export
```

---

## 8. Part C: One-Click Standalone PWA ZIP Builder

Add a visible button:

```text
Build Standalone PWA ZIP
```

Required behavior:

1. Collect the current project data.
2. Collect all project assets.
3. Create or repair `index.html`.
4. Create or repair `manifest.json`.
5. Create or repair `service-worker.js`.
6. Create or repair `styles.css`.
7. Create or repair `app.js`.
8. Create or repair `assets/icons/`.
9. Create or repair `assets/images/`.
10. Create or repair project data.
11. Compress oversized images where possible.
12. Rewrite broken asset paths into valid relative paths.
13. Remove unsafe external scripts unless trusted mode is explicitly enabled.
14. Generate offline cache list.
15. Generate required PWA icons if missing.
16. Validate the completed package.
17. Run security scan.
18. Run offline readiness scan.
19. Generate export receipt.
20. Download the finished ZIP.

Minimum ZIP output:

```text
index.html
manifest.json
service-worker.js
styles.css
app.js
project-data.json or book-data.json or chapters.json
assets/icons/icon-192.png
assets/icons/icon-512.png
assets/images/
README.md
export-receipt.json
security-report.json
```

The generated ZIP must open as an app/site, not raw source code.

Success condition:
Do not show success unless a real ZIP Blob/File was created and validated.

---

## 9. Part D: Live Build Steps UI

After clicking Build Standalone PWA ZIP, show a live build checklist:

```text
1. Reading project
2. Checking required files
3. Repairing missing files
4. Compressing images
5. Generating manifest
6. Generating service worker
7. Building offline cache
8. Validating paths
9. Running security scan
10. Running PWA readiness scan
11. Creating ZIP
12. Creating receipt
13. Download ready
```

Each step must return:

```text
PASS
FAIL
WARNING
SKIPPED
```

Critical failure behavior:

- Stop the build.
- Show exact reason.
- Show suggested fix.
- Do not download a broken ZIP unless the user chooses “Export With Warnings.”
- Never offer “Export With Warnings” for security blockers.

Critical blockers:

```text
missing index.html that cannot be generated
missing app data
unsafe executable file
dangerous script detected
hard-coded secret detected
credential capture form detected
path traversal detected
service worker cannot be generated
manifest cannot be generated
```

---

## 10. Part E: Security Scanner

Every generated ZIP must be scanned before download.

Detect and report:

```text
external script tags
dangerous inline scripts
redirect scripts
credential capture forms
forms requesting password, payment card, token, or API key
suspicious iframe usage
javascript: URLs
unexpected data URLs
path traversal
absolute local paths
.exe files
.bat files
.cmd files
.sh files
.app files
.dmg files
hidden .env files
hard-coded API keys
service worker network hijacking
tracking pixels
unknown external domains
oversized files
```

Severity levels:

```text
BLOCKER
HIGH
MEDIUM
LOW
INFO
```

Block export by default for:

```text
executable files
credential capture forms
hard-coded API keys
hidden .env files
malicious redirects
path traversal
unsafe service worker behavior
dangerous external scripts
```

Security report format:

```js
const securityIssue = {
  issue: "Hard-coded API key detected",
  file: "app.js",
  severity: "BLOCKER",
  recommendedFix: "Remove the key from the exported package and require user entry in Settings.",
  blocksExport: true
};
```

Output required:

```text
security-report.json
visible safety report panel
```

---

## 11. Part F: Export Receipts

Generate a receipt after every export.

Exports requiring receipts:

```text
standalone HTML
PWA ZIP
Load Studio package
backup
diagnostic report
LoadPlay publish-prep package
standalone book PWA
```

Receipt structure:

```js
const receipt = {
  exportType: "PWA ZIP",
  fileName: "project.zip",
  fileSize: 0,
  createdAt: new Date().toISOString(),
  includedFiles: [],
  missingFiles: [],
  warnings: [],
  manifestStatus: "NOT TESTED",
  serviceWorkerStatus: "NOT TESTED",
  rightsStatus: "NOT TESTED",
  offlineStatus: "NOT TESTED",
  safetyStatus: "NOT TESTED",
  nextAction: ""
};
```

Required buttons:

```text
Download Receipt
Copy Receipt
Save Receipt to Library
```

---

## 12. Part G: LoadStudio Package Validator

Recognize:

```text
.loadstudio.zip
.cinepwa.zip
```

Required files:

```js
const REQUIRED_LOADSTUDIO_FILES = [
  "index.html",
  "manifest.json",
  "service-worker.js",
  "project.json",
  "scenes.json",
  "characters.json",
  "rights.json",
  "credits.json",
  "styles.css",
  "player.js",
  "editor.js"
];
```

Required folders:

```js
const REQUIRED_LOADSTUDIO_FOLDERS = [
  "assets/images/",
  "assets/audio/",
  "assets/music/",
  "assets/sfx/",
  "assets/subtitles/",
  "assets/icons/"
];
```

Validator return format:

```js
{
  valid: true,
  status: "PASS",
  missingFiles: [],
  missingFolders: [],
  warnings: [],
  errors: []
}
```

Validation rules:

- PASS if all required files and folders exist.
- WARNING if non-critical assets are missing.
- FAIL if `project.json`, `scenes.json`, `rights.json`, or `index.html` is missing.
- Block LoadPlay publish-prep without `rights.json`.
- Block unsafe preview unless sandbox mode is active.

Required UI actions:

```text
Open as Viewer
Open as Editable Project
Validate Package
Repair Package
Export Fixed Package
Prepare for LoadStudio
Prepare for LoadPlay
```

---

## 13. Part H: Rights Metadata Validator

Required rights structure:

```json
{
  "owner": "Creator name or company",
  "license": "user-owned",
  "sourceMaterial": "Original manuscript, public domain source, licensed source, or platform original",
  "assetDeclarations": [
    {
      "asset": "assets/images/scene_001.png",
      "status": "user-generated"
    }
  ],
  "notes": "Creator confirms rights to upload and distribute."
}
```

Validator:

```js
function validateRights(rights) {
  const errors = [];
  const warnings = [];

  if (!rights) errors.push("rights.json is missing.");
  if (!rights?.owner) errors.push("Rights owner is missing.");
  if (!rights?.license) errors.push("License is missing.");
  if (!rights?.sourceMaterial) errors.push("Source material is missing.");
  if (!Array.isArray(rights?.assetDeclarations)) {
    errors.push("Asset declarations must be an array.");
  }

  const hasUnknown = rights?.assetDeclarations?.some(a => a.status === "unknown");
  if (hasUnknown) warnings.push("Some assets have unknown rights status.");

  return {
    valid: errors.length === 0 && warnings.length === 0,
    errors,
    warnings
  };
}
```

Supported status values:

```text
user-owned
public-domain
licensed
platform-original
user-generated
user-recorded
third-party-licensed
unknown
```

Block LoadPlay publish-prep if rights are missing or unresolved.

---

## 14. Part I: Safer Sandbox Preview

For untrusted packages, default to:

```html
<iframe sandbox="allow-scripts" referrerpolicy="no-referrer"></iframe>
```

Do not allow by default:

```text
allow-same-origin
allow-forms
allow-popups
```

Add a Trust Package flow:

```text
Mark Package Trusted
```

Before enabling broader iframe permissions, show:

```text
This package may access browser storage, submit forms, open popups, or communicate with external services. Only trust files you created or fully reviewed.
```

Required modes:

```text
Strict Sandbox
Trusted Preview
Blocked Preview
```

---

## 15. Part J: Ecosystem Routing

Add visible ecosystem action buttons.

For HTML/PWA:

```text
Preview Sandboxed
Repair Manifest
Repair Service Worker
Build Standalone PWA ZIP
Prepare for LoadStudio
Prepare for LoadPlay
```

For books/documents:

```text
Open Reader
Convert to Digital Book Project
Export EPUB
Export PDF
Export Standalone Book PWA
Send to LoadStudio as Source Material
```

For media:

```text
Open Player
Add to Project
Send to LoadStudio
```

For LoadStudio packages:

```text
Open as Viewer
Open as Editable Project
Validate Package
Repair Package
Export Fixed Package
Prepare for LoadPlay
```

For LoadPlay prep:

```text
Validate Rights
Validate Safety
Generate Publish Package
Export Publish Report
```

---

## 16. Part K: Sample Test Projects

Add a Sample Projects section.

Include:

```text
Sample HTML app
Sample PWA ZIP
Sample EPUB
Sample PDF
Sample image file
Sample audio file
Sample video file
Sample LoadStudio package
Sample digital book PWA
```

Each sample must include:

```text
Open
Test
Export
Reset sample
```

Purpose:
New users and developers must be able to test Load without uploading anything.

---

## 17. Part L: Suggested File or Module Layout

Create or update modules similar to these:

```text
/src/diagnostics/feature-tests.js
/src/diagnostics/report-exporter.js
/src/packages/zip-inspector.js
/src/packages/loadstudio-validator.js
/src/packages/safety-validator.js
/src/packages/rights-validator.js
/src/packages/export-receipts.js
/src/pwa/pwa-exporter.js
/src/pwa/manifest-repair.js
/src/pwa/service-worker-builder.js
/src/sandbox/sandbox-preview.js
/src/ai/provider-router.js
/src/voice/piper-diagnostics.js
/src/samples/sample-projects.js
/src/ecosystem/load-routing.js
```

If the project does not use `/src`, adapt to the existing file structure but keep modules cleanly separated.

---

## 18. Acceptance Criteria

The patch is not complete unless:

1. Load launches without console-breaking errors.
2. Main navigation works.
3. Import buttons trigger real file selection.
4. Imported files save to Library.
5. Library files reopen.
6. Diagnostics panel exists.
7. Run All Tests works.
8. Diagnostic report exports.
9. HTML/PWA packages preview in sandbox.
10. Manifest repair test works.
11. Service worker generation test works.
12. PWA ZIP export creates an actual ZIP.
13. One-click Build Standalone PWA ZIP creates a real ZIP Blob/File.
14. The generated ZIP includes all required files.
15. The generated ZIP includes `export-receipt.json`.
16. The generated ZIP includes `security-report.json`.
17. Digital book PWA export creates a true standalone app, not raw code.
18. Export receipt appears after export.
19. LoadStudio package validator exists.
20. `.loadstudio.zip` and `.cinepwa.zip` can be inspected.
21. `rights.json` is required for publish-prep.
22. Safety report blocks unsafe packages.
23. LoadStudio and LoadPlay routing buttons are visible.
24. AI copy no longer contradicts privacy/offline copy.
25. The two prohibited reading-accessibility terms are removed from user-facing interface text.
26. Piper errors are caught and explained.
27. No feature is labeled complete unless it was tested.
28. Final report lists files changed, files added, tests passed, tests failed, known limitations, and remaining future work.

---

## 19. Final Report Required From Claude

When finished, Claude must provide:

1. Summary of what changed.
2. Files changed.
3. Files added.
4. Features now working.
5. Features still incomplete.
6. Tests performed.
7. Failed tests.
8. Security risks remaining.
9. Exact upload/build instructions.
10. Exact files to upload or replace.
11. Confirmation that only necessary files are included.
12. Confirmation that no feature was marked complete without a real test.
13. Confirmation that the one-click PWA ZIP builder created a real ZIP Blob/File.
14. Confirmation that unsafe packages are blocked before export.
15. Confirmation that user-facing prohibited wording was removed.

---

## 20. Upload Rule

When delivering files back to the user, include only the exact files that need to be uploaded or replaced. Do not include unnecessary files.

This matters because GitHub deletes and uploads have previously caused version instability.

---

## 21. Developer Priority Order

Build in this order:

1. Copy cleanup and truth alignment.
2. Feature Verification Dashboard.
3. Security scanner.
4. Export receipts.
5. One-click Standalone PWA ZIP Builder.
6. LoadStudio package validator.
7. Rights metadata validator.
8. Safer sandbox preview.
9. Ecosystem routing.
10. Sample test projects.
11. Final verification and handoff report.

Do not prioritize visual polish before these operational requirements.

---

## 22. Final Strategic Direction

Load Main should become the intake, repair, verification, and export hub of the full Load ecosystem.

Its core job:

```text
Open anything. Inspect it. Repair it. Secure it. Export it. Route it to LoadStudio or LoadPlay.
```

The strongest next milestone is not another design pass. The strongest milestone is a trustworthy one-click builder that produces a secure standalone PWA ZIP with a receipt and safety report.

