# Load AI Chat Reliability Infrastructure Addendum
## Claude-ready build plan for reliability, fallback, proof, and production pipeline stability

Prepared for Claude handoff  
Purpose: Add reliability infrastructure to the Load AI Chat / LoadStudio AI build so the system is not only provider-rich, but dependable, testable, and production-safe.

IMPORTANT:
This is an addendum to the existing Load AI Cinema System plan and the free/open-source/local-first provider extension plan.

Do not replace the prior plans.
Add this reliability infrastructure on top of them.

---

# 1. Core principle

Do not only add providers.

Providers give Load generation routes. Reliability comes from the systems around those providers.

The Load AI Chat system must be able to:

- test providers
- route around failures
- prove outputs exist
- queue long jobs
- recover from stalls
- prevent false success claims
- preserve rights metadata
- attach assets to scenes
- export valid packages
- keep user work safe

The goal is a reliable production pipeline, not a fragile AI demo.

---

# 2. Required reliability builds

Add the following reliability systems to the Load AI Chat / LoadStudio build plan.

## 1. Provider Health Monitor

Add a tool/page that tests every provider/tool and shows a clear status.

Required statuses:

```text
Ready
Not configured
Failed
Rate limited
Returned no file
Local server unavailable
Unsupported request
Offline
Needs user setup
```

The health monitor must test:

```text
image
image-to-image
animation/video
audio/SFX
voice/narration
local server connection
prompt-only fallback
```

Rule:
Do not mark any provider READY unless a real test succeeds.

---

## 2. Auto-Fallback Router

If one provider fails, Load should automatically try the next valid route.

Example image fallback order:

```text
Load AI Image → Pollinations → AI Horde → Hugging Face route → Local SD → Prompt-only fallback
```

Example animation fallback order:

```text
ComfyUI video workflow → local video server → Pollinations video if available → Prompt-only motion fallback
```

Example sound fallback order:

```text
user-imported SFX → local SFX library → local audio model → sound prompt saved
```

Purpose:
The system should not break because one provider fails.

---

## 3. Output Proof Gate

Every generated output must pass a proof gate before the UI says it worked.

Required checks:

```text
Image exists as file/blob/URL
Video exists and is playable
Audio exists and is playable
ZIP exists and validates
Scene attachment exists
Rights metadata exists
Asset declaration exists
```

If proof fails, the system must say one of:

```text
Generation failed
Returned no file
Prompt saved instead
Provider unavailable
```

No false positives.

---

## 4. Generation Queue

Do not let image/video/audio jobs run chaotically.

Add a generation queue with statuses:

```text
Queued
Preparing
Generating
Saving
Attaching to scene
Complete
Failed
Cancelled
Retrying
```

This is especially important for:

```text
image animation
video generation
audio/SFX generation
voice/narration generation
package export
```

---

## 5. Retry and Resume System

If Safari reloads, the app stalls, or a job fails, Load should not lose the work.

Add:

```text
retry failed job
resume pending job
save job state
recover last prompt
recover last source image
recover last output if available
```

Store job state in:

```text
generation-queue.json
generation-report.json
chat-history.json
```

---

## 6. Provider Timeout Rules

Each provider type should have a timeout.

Suggested defaults:

```text
image: 45 seconds
image-to-image: 60 seconds
video/animation: 3 to 8 minutes
audio/SFX: 60 to 120 seconds
voice/narration: 60 to 120 seconds
local server check: 10 seconds
provider connection test: 10 seconds
```

If a provider times out, Load should move to fallback or show a clear message.

---

## 7. Local-only Mode

Add a toggle:

```text
Local-only mode
```

When enabled, Load uses only:

```text
built-in tools
local models
user-imported assets
local SFX library
browser TTS
Piper
Kokoro where configured
prompt-only fallback
```

No cloud calls.

This protects privacy and supports offline/local-first creation.

---

## 8. Provider Budget / Cost Guard

Even though paid providers are not MVP requirements, add a future-safe guard.

Required behavior:

```text
Paid providers off by default
Warn before paid provider use
Show estimated cost if provider supports it
Never auto-call paid provider
Never use paid provider as fallback unless user explicitly enables it
```

This prevents expensive surprises later.

---

## 9. Asset Rights Inspector

Every generated or imported asset should have a rights status.

Required statuses:

```text
user-owned
public-domain
licensed
platform-original
user-generated
user-recorded
third-party-licensed
unknown
needs-review
```

If rights status is unknown, block LoadPlay publish-prep.

The inspector must connect to:

```text
rights.json
asset-declarations.json
generation-report.json
```

---

## 10. Scene Asset Dependency Checker

Before export, check that every scene file exists.

Required checks:

```text
image exists
video exists
audio exists
music exists
SFX exists
subtitle exists
rights metadata exists
asset declaration exists
no broken asset path
no unattached generated asset
```

If missing, show:

```text
Missing file
Broken path
Unattached asset
Rights missing
```

---

## 11. Web Audio Scene Mixer

Add a Web Audio Scene Mixer so LoadStudio can preview layered sound.

It should preview:

```text
video
narration
ambience
SFX
music
voice
```

Purpose:
Creators should be able to hear a scene with separate audio layers before muxing everything into one final video.

---

## 12. Audio Cue Sheet / Timeline SFX System

Scenes need timed sound cues.

Example:

```json
{
  "sceneId": "scene_ark_001",
  "audioCues": [
    {
      "time": 0.5,
      "type": "ambience",
      "asset": "assets/sfx/crowd_bed.mp3"
    },
    {
      "time": 2.1,
      "type": "sfx",
      "asset": "assets/sfx/mocking_laughter.mp3"
    },
    {
      "time": 3.4,
      "type": "sfx",
      "asset": "assets/sfx/wood_hammer.mp3"
    }
  ]
}
```

This is a serious film-production feature and should be stored in scene/project data.

---

## 13. FFmpeg / Audio-Video Muxing Future Path

Add as later/future, not MVP blocker:

```text
Mux video + audio into final MP4
Extract audio from video
Convert audio formats
Compress video
Create preview proxy
```

Possible routes:

```text
FFmpeg.wasm
backend FFmpeg
Load Local Engine
```

Do not block MVP on muxing, but reserve the architecture for it.

---

## 14. Model Capability Audit

Every model/provider should declare what it actually supports.

Example:

```json
{
  "providerId": "pollinations-flux",
  "capabilities": {
    "image": true,
    "imageToImage": false,
    "imageAnimation": false,
    "audio": false,
    "sfx": false,
    "voice": false
  }
}
```

This prevents sending audio requests to an image-only provider or video requests to an audio-only provider.

---

## 15. Prompt Compiler

This is a critical reliability feature.

Instead of sending raw user text directly, Load should compile prompts into production layers.

Required prompt layers:

```text
visualPrompt
negativePrompt
motionPrompt
cameraPrompt
characterMotionPrompt
environmentPrompt
soundPrompt
musicPrompt
sfxPrompt
voicePrompt
rightsPrompt
```

Example user text:

```text
Bring this image to life with noise and mocking laughter
```

Compiled output:

```json
{
  "visualPrompt": "Animate the ark construction scene with people moving and gesturing.",
  "motionPrompt": "Slow cinematic push-in, crowd shifting, workers hammering.",
  "soundPrompt": "Noisy crowd, mocking laughter, wood hammering, distant animals.",
  "sfxPrompt": "mocking laughter, hammering wood, dusty outdoor crowd.",
  "musicPrompt": "low tense ancient cinematic underscore."
}
```

This makes the AI chat professional and production-safe.

---

## 16. Continuity Lock System

For characters and scenes, add:

```text
Lock character appearance
Lock wardrobe
Lock era
Lock style
Lock location
Lock tone
Lock voice direction
Lock lighting direction
```

This helps prevent output drift across images, animations, voices, and scenes.

---

## 17. Versioned Generation History

Every output should be versioned.

Example:

```text
scene_001_image_v1
scene_001_image_v2
scene_001_animation_v1
scene_001_animation_v2
scene_001_audio_v1
scene_001_audio_v2
```

Users should be able to:

```text
view previous versions
restore a previous version
compare versions
delete failed versions
keep final version
```

---

# 3. Priority order for implementation

Add these first:

```text
1. Provider Health Monitor
2. Output Proof Gate
3. Auto-Fallback Router
4. Generation Queue
5. Prompt Compiler
6. Web Audio Scene Mixer
7. Asset Rights Inspector
8. Scene Asset Dependency Checker
```

These eight will make Load feel reliable instead of experimental.

Then add:

```text
9. Retry and Resume System
10. Provider Timeout Rules
11. Local-only Mode
12. Audio Cue Sheet / Timeline SFX system
13. Continuity Lock System
14. Versioned Generation History
15. FFmpeg / muxing future path
16. Model Capability Audit, if not already included in provider registry
17. Provider Budget / Cost Guard
```

---

# 4. Claude-ready instruction block

Claude, add reliability infrastructure to the Load AI Chat build plan.

Do not only add providers. Add the systems that make generation reliable.

Required reliability builds:

1. Provider Health Monitor
2. Auto-Fallback Router
3. Output Proof Gate
4. Generation Queue
5. Retry and Resume System
6. Provider Timeout Rules
7. Local-only Mode
8. Provider Budget/Cost Guard for future paid connectors
9. Asset Rights Inspector
10. Scene Asset Dependency Checker
11. Web Audio Scene Mixer
12. Audio Cue Sheet / Timeline SFX system
13. FFmpeg/Audio-Video Muxing future path
14. Model Capability Audit
15. Prompt Compiler
16. Continuity Lock System
17. Versioned Generation History

Rules:

- Do not mark any provider READY without a real test.
- Do not claim image/video/audio success without real output proof.
- Do not export API keys.
- Keep free/open-source/local-first providers as MVP priority.
- Paid providers remain future optional only, off by default.
- Store outputs in structured project files, not only chat.
- Keep Load Main as the AI infrastructure and validation hub.
- Keep LoadStudio as the creative production cockpit.
- Do not build a provider-dependent app.
- Build the Load-owned AI operating layer first.

---

# 5. Acceptance criteria

This reliability layer is not complete unless:

```text
1. Provider Health Monitor exists or is honestly marked NOT DONE.
2. Auto-Fallback Router exists or is honestly marked NOT DONE.
3. Output Proof Gate exists or is honestly marked NOT DONE.
4. Generation Queue exists or is honestly marked NOT DONE.
5. Retry/Resume system exists or is honestly marked NOT DONE.
6. Provider Timeout Rules exist or are honestly marked NOT DONE.
7. Local-only Mode exists or is honestly marked NOT DONE.
8. Provider Budget/Cost Guard exists or is honestly marked NOT DONE.
9. Asset Rights Inspector exists or is honestly marked NOT DONE.
10. Scene Asset Dependency Checker exists or is honestly marked NOT DONE.
11. Web Audio Scene Mixer exists or is honestly marked NOT DONE.
12. Audio Cue Sheet exists or is honestly marked NOT DONE.
13. FFmpeg/muxing future path is documented.
14. Model Capability Audit exists or is honestly marked NOT DONE.
15. Prompt Compiler exists or is honestly marked NOT DONE.
16. Continuity Lock System exists or is honestly marked NOT DONE.
17. Versioned Generation History exists or is honestly marked NOT DONE.
18. No provider is marked READY without a real test.
19. No output is marked successful without output proof.
20. No API key is exported.
```

Use only these status labels:

```text
VERIFIED
READY FOR USER VERIFICATION
NOT DONE
```

---

# 6. Final strategic instruction

The Load AI system must not be a fragile AI demo.

It must be a reliable, production-aware system that supports:

```text
prompt → provider routing → generation → proof → save → attach → rights → continuity → export → validation
```

This is how Load AI Chat becomes dependable for real movie/content creation.
