# Load AI Generator Master Build Plan

Prepared for Claude handoff  
Purpose: Add the Load AI Model Independence System to the Load ecosystem roadmap and provide a complete future build specification for X-AI-CORE and X-STUDIO-AI.

Important usage note:
Do not give this to Claude until the Load Main v17g10 home-page discoverability patch is complete and confirmed.

---

# 1. Core Concept

The AI generator should not be treated as a small chat feature. It should become the Load-owned creative intelligence system that can power Load Main, LoadStudio, and later LoadPlay without depending on one outside provider.

Correct structure:

```text
Load Main = AI core infrastructure
LoadStudio = AI creative production engine
LoadPlay = AI catalog/moderation support later
```

Strategic goal:

```text
Build Load’s own model-independent AI creation system that can use local models, open-source models, optional cloud providers, and future Load-hosted models without being locked to one API key or one company.
```

---

# 2. Product Name

Recommended system name:

```text
Load Creation Engine
```

Technical layer names:

```text
X-AI-CORE = Load Main shared AI infrastructure
X-STUDIO-AI = LoadStudio creative production system
```

Plain-language product description:

```text
Load Creation Engine turns books, scripts, documents, images, audio, and creator notes into structured scene projects, character bibles, visual prompts, voice directions, video prompts, editable assets, and LoadStudio cinema packages.
```

---

# 3. Placement Across Load Ecosystem

## A. Load Main Placement

Load Main should contain the infrastructure layer.

Load Main owns:

```text
AI Core Settings
Model Connector Manager
Provider Router
Local Model Connector
Open-Source Model Connector
Optional Cloud Provider Connector
Project Memory
Rights Metadata Writer
Safety Scanner Integration
Output Proof Rules
AI Diagnostic Report
Model Status Tests
Prompt-only Fallback
```

Load Main should answer:

```text
Which model is available?
Is this model local, open-source, cloud, or prompt-only?
What can this model generate?
Did the model return a real file/blob/URL?
Can the output be exported safely?
Are rights metadata and safety reports attached?
Can this project be routed to LoadStudio or LoadPlay?
```

Load Main should not do:

```text
Full scene editing
Full cinematic timeline editing
Advanced character/wardrobe production
Full video production workflow
Creator channel publishing
Subscription logic
```

---

## B. LoadStudio Placement

LoadStudio should contain the creative production layer.

LoadStudio owns:

```text
AI Scene Builder
Book-to-Cinema Workflow
Script-to-Shot Workflow
Character Bible Generator
Style Bible Generator
Voice Bible Generator
Wardrobe Continuity Tracker
Prompt Studio
Image Prompt Generator
Video Prompt Generator
Music/SFX Prompt Generator
Scene Consistency Checker
Character Consistency Checker
Generation Queue
Output Review
Export to .loadstudio.zip / .cinepwa.zip
```

LoadStudio should answer:

```text
How do I turn this book into scenes?
How do I keep the same character consistent?
How do I create a shot list?
How do I generate image/video/voice prompts?
How do I attach outputs to scenes.json?
How do I export a playable/editable LoadStudio package?
```

---

## C. LoadPlay Placement

LoadPlay should not be the AI creation center.

Later, LoadPlay can use AI for:

```text
Catalog tagging
Content moderation
Caption assistance
Thumbnail suggestions
Upload review
Search enrichment
Recommendation support
Rights metadata review
```

LoadPlay should receive validated content. It should not become the main AI studio.

---

# 4. Build Order

Do not build this before the current Load Main discoverability patch is complete.

Recommended order:

```text
1. Complete Load Main v17g10 discoverability patch
2. Confirm Load Main user verification items
3. Add X-AI-CORE roadmap files and UI placeholders
4. Build X-AI-CORE in Load Main
5. Build X-STUDIO-AI in LoadStudio
6. Connect X-STUDIO-AI to X-VIDEO-AI
7. Then continue X-DB
8. Then X-SUBS
```

Do not let Claude start coding this while Load Main v17g10 still needs verification.

---

# 5. X-AI-CORE Build Specification for Load Main

## Purpose

X-AI-CORE is the shared AI infrastructure layer. It makes Load independent of any single AI company, while allowing local, open-source, optional cloud, and future Load-hosted models.

## Required Screens in Load Main

Add a new top-level tool area:

```text
Load AI Core
```

Inside it:

```text
AI Core Settings
Model Connectors
Provider Status
Prompt-only Fallback
Project Memory
Rights & Safety
AI Diagnostics
Export AI Report
```

## Required Files/Modules

Use the existing project structure if different, but conceptually create:

```text
/load/ai-core/index.html
/load/ai-core/ai-core.js
/load/ai-core/provider-router.js
/load/ai-core/model-registry.js
/load/ai-core/model-capabilities.js
/load/ai-core/local-model-connector.js
/load/ai-core/open-source-connector.js
/load/ai-core/cloud-provider-connector.js
/load/ai-core/prompt-only-connector.js
/load/ai-core/project-memory.js
/load/ai-core/output-proof.js
/load/ai-core/rights-writer.js
/load/ai-core/safety-ai-bridge.js
/load/ai-core/ai-diagnostics.js
/load/ai-core/ai-report-exporter.js
/load/ai-core/model-settings.html
/load/ai-core/model-settings.js
```

If Claude cannot use folders, then use:

```text
load-ai-core.html
load-ai-core.js
provider-router.js
model-registry.js
model-capabilities.js
project-memory.js
output-proof.js
rights-writer.js
ai-diagnostics.js
```

---

# 6. Model Independence Architecture

## Required Provider Types

X-AI-CORE must support these connector types:

```text
local
open-source
cloud-optional
load-hosted-future
prompt-only
```

## Provider Status Values

Every connector must report one of:

```text
Not configured
Ready
Failed
Rate limited
Unsupported request
Returned no file
Offline
Local server unavailable
Needs user setup
```

## Capability Detection

Each model connector must declare capabilities:

```json
{
  "providerId": "local-comfyui",
  "providerName": "Local ComfyUI",
  "providerType": "local",
  "enabled": false,
  "requiresApiKey": false,
  "requiresLocalServer": true,
  "endpoint": "http://localhost:8188",
  "capabilities": {
    "text": false,
    "image": true,
    "video": false,
    "audio": false,
    "voice": false,
    "embeddings": false,
    "safety": false,
    "documentParsing": false
  },
  "status": "Needs user setup"
}
```

## Fallback Routing Order

Default routing order:

```text
1. Local model where available
2. Open-source connector
3. User-enabled optional cloud provider
4. Prompt-only fallback
```

Never make one outside provider mandatory.

---

# 7. Output Proof Rules

This must be non-negotiable.

```text
Never claim image generation succeeded unless a real file/blob/URL exists.
Never claim audio generation succeeded unless a playable file/blob exists.
Never claim video generation succeeded unless a playable file/blob/URL exists.
Never claim text generation succeeded unless non-empty text exists.
Never claim ZIP generation succeeded unless Blob passes ZIP header check.
Never claim model is ready unless a real test response succeeds.
```

## Output Proof Schema

```json
{
  "outputId": "output_001",
  "requestId": "request_001",
  "providerId": "local-comfyui",
  "type": "image",
  "status": "VERIFIED_OUTPUT",
  "fileUrl": "assets/images/scene_001.png",
  "blobVerified": true,
  "mimeType": "image/png",
  "sizeBytes": 345122,
  "createdAt": "2026-05-06T00:00:00.000Z",
  "proof": {
    "hasFile": true,
    "hasBlob": true,
    "hasUrl": false,
    "playable": null,
    "nonEmptyText": null
  }
}
```

---

# 8. Project Memory System

Load should have structured memory per project, not just chat history.

## Required Project Memory Files

```text
ai-project.json
model-routing.json
scene-plan.json
characters.json
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
rights.json
continuity-report.json
asset-declarations.json
```

## ai-project.json

```json
{
  "projectId": "load_project_001",
  "projectType": "load.ai.creation",
  "title": "Untitled AI Creation Project",
  "sourceType": "book",
  "sourceFiles": [],
  "createdAt": "2026-05-06T00:00:00.000Z",
  "updatedAt": "2026-05-06T00:00:00.000Z",
  "status": "draft",
  "targetExport": [
    ".loadstudio.zip",
    ".cinepwa.zip"
  ]
}
```

## model-routing.json

```json
{
  "routingMode": "local-first",
  "fallbackEnabled": true,
  "providers": [],
  "lastSuccessfulProvider": null,
  "promptOnlyFallback": true
}
```

## prompt-log.json

```json
{
  "prompts": [
    {
      "promptId": "prompt_001",
      "sceneId": "scene_001",
      "type": "image",
      "providerId": "prompt-only",
      "prompt": "cinematic opening scene...",
      "negativePrompt": "distorted face, extra limbs, unreadable text",
      "createdAt": "2026-05-06T00:00:00.000Z",
      "status": "drafted"
    }
  ]
}
```

---

# 9. Rights and Safety Integration

Every generated output must carry rights metadata.

## Required Rights Fields

```json
{
  "owner": "Creator name or company",
  "license": "user-owned",
  "sourceMaterial": "Original manuscript",
  "assetDeclarations": [
    {
      "asset": "assets/images/scene_001.png",
      "status": "user-generated",
      "provider": "local-comfyui",
      "model": "model-name",
      "promptId": "prompt_001",
      "commercialUseStatus": "needs-review"
    }
  ],
  "notes": "Creator confirms rights to upload and distribute."
}
```

## Rights Statuses

```text
user-owned
public-domain
licensed
platform-original
user-generated
user-recorded
third-party-licensed
unknown
needs-review
```

## Safety Checks

The AI generator must check for:

```text
missing rights metadata
unknown asset rights
unsafe prompts
unsafe generated outputs
hard-coded provider API keys
hidden .env files
external URLs
credential capture forms
unverified model outputs
blocked publish status
```

---

# 10. X-STUDIO-AI Build Specification for LoadStudio

## Purpose

X-STUDIO-AI is the creative production engine inside LoadStudio. It uses Load Main’s X-AI-CORE to produce structured scenes, prompts, characters, voices, styles, and exportable packages.

## Required Screens in LoadStudio

```text
Load Creation Engine
AI Scene Builder
Book-to-Cinema
Script-to-Shot
Character Bible
Style Bible
Voice Bible
Wardrobe Continuity
Prompt Studio
Generation Queue
Output Review
Continuity Check
Export to LoadStudio Package
```

## Required Files/Modules

```text
/loadstudio/ai/creation-engine.html
/loadstudio/ai/creation-engine.js
/loadstudio/ai/book-to-cinema.js
/loadstudio/ai/script-to-shot.js
/loadstudio/ai/scene-builder.js
/loadstudio/ai/character-bible.js
/loadstudio/ai/style-bible.js
/loadstudio/ai/voice-bible.js
/loadstudio/ai/wardrobe-bible.js
/loadstudio/ai/prompt-studio.js
/loadstudio/ai/generation-queue.js
/loadstudio/ai/output-review.js
/loadstudio/ai/continuity-checker.js
/loadstudio/ai/export-loadstudio-package.js
```

---

# 11. LoadStudio AI Workflows

## Workflow 1: Book to Cinema

Steps:

```text
1. Import book, PDF, DOCX, EPUB, TXT, Markdown, or existing Load book project.
2. Extract title, chapters, sections, characters, locations, and tone.
3. Split source into scene cards.
4. Generate scene summaries.
5. Generate narration drafts.
6. Generate character bible entries.
7. Generate visual style bible.
8. Generate image prompts and negative prompts.
9. Generate video prompts.
10. Generate voice directions.
11. Generate music/SFX notes.
12. Save all data into structured JSON.
13. Allow user review and edit.
14. Attach generated or imported assets.
15. Export as .loadstudio.zip or .cinepwa.zip.
```

## Workflow 2: Script to Shot

Steps:

```text
1. Import script or paste script.
2. Detect scenes.
3. Detect dialogue.
4. Detect characters.
5. Detect locations.
6. Generate shot list.
7. Generate camera directions.
8. Generate prompt package per shot.
9. Generate scene timing.
10. Export scene cards and prompts.
```

## Workflow 3: Character Bible

Required fields:

```json
{
  "characterId": "character_001",
  "name": "Character Name",
  "ageRange": "adult",
  "appearance": "locked appearance",
  "hair": "locked hair",
  "skinTone": "locked skin tone",
  "bodyType": "locked body type",
  "clothing": "locked clothing",
  "era": "locked era",
  "voiceStyle": "voice direction",
  "personality": "brief traits",
  "referenceImages": [],
  "consistencyRules": "Do not change face, age, wardrobe, or era.",
  "negativeTraitsToAvoid": "do not modernize wardrobe, do not alter identity"
}
```

## Workflow 4: Prompt Studio

Prompt types:

```text
image prompt
negative prompt
video prompt
voice prompt
music prompt
SFX prompt
subtitle prompt
narration prompt
continuity check prompt
rights metadata prompt
```

## Workflow 5: Continuity Check

Check:

```text
character face consistency
wardrobe consistency
era consistency
location continuity
scene order
voice consistency
visual style drift
missing assets
missing rights metadata
missing prompts
unverified outputs
```

---

# 12. Export Requirements

X-STUDIO-AI must export AI-built projects into the existing package structure.

## Required .loadstudio.zip / .cinepwa.zip Files

```text
index.html
manifest.json
service-worker.js
project.json
scenes.json
characters.json
rights.json
credits.json
styles.css
player.js
editor.js
assets/images/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
assets/icons/
```

## Additional AI Files

```text
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
continuity-report.json
model-routing.json
asset-declarations.json
```

These extra files should not break the validator. They should enhance the package.

---

# 13. UI Principle

The AI generator must not feel like a generic chatbox.

It should feel like a production control system.

Use this structure:

```text
Input
Plan
Generate
Review
Attach
Validate
Export
```

## Main UI Sections

```text
1. Source Material
2. Project Plan
3. Characters
4. Scenes
5. Prompts
6. Generation Queue
7. Outputs
8. Continuity
9. Rights & Safety
10. Export
```

---

# 14. Prompt-only Fallback

This is important.

Even if no model is connected, Load should still generate and export:

```text
scene cards
character bibles
style bibles
voice bibles
image prompts
video prompts
music/SFX prompts
negative prompts
rights metadata drafts
continuity reports
```

This means the system remains useful without API keys.

Label this mode:

```text
Prompt-only Mode
```

User-facing explanation:

```text
No generation model is connected. Load can still build structured scene plans, prompts, bibles, and export-ready project files for use with your preferred model.
```

---

# 15. Build Acceptance Criteria

The AI generator is not complete unless:

```text
1. Load Main has X-AI-CORE settings screen.
2. Model connector registry exists.
3. Capability detection exists.
4. Provider statuses exist.
5. Prompt-only fallback works.
6. Local/open-source connector placeholders exist.
7. Optional cloud providers are off by default.
8. No API keys are hard-coded.
9. Output proof rules exist.
10. Rights metadata writer exists.
11. Safety integration exists.
12. AI diagnostic report exports.
13. LoadStudio can open Load Creation Engine.
14. LoadStudio can generate scene cards from source text.
15. LoadStudio can generate character bible entries.
16. LoadStudio can generate style bible.
17. LoadStudio can generate image and video prompts.
18. LoadStudio can create prompt-log.json.
19. LoadStudio can create generation-report.json.
20. LoadStudio can attach outputs to scenes.
21. LoadStudio can export .loadstudio.zip / .cinepwa.zip.
22. Exported packages pass Load Main validator.
23. No success message appears without verified output.
24. Failed generation returns prompt and reason.
25. User can continue in prompt-only mode.
```

---

# 16. Claude-ready Full Prompt

Give Claude this after the Load Main v17g10 patch is complete.

```text
Claude, start the next major roadmap item: Load AI Model Independence System.

Before coding, read:
- SESSION_NOTES_2026-05-06.md
- CLAUDE.md
- current Load Main build notes
- current LoadStudio build notes

Do not start this if the Load Main v17g10 home-page discoverability patch is not complete and confirmed.

Goal:
Build the Load AI Model Independence System so Load has its own core AI infrastructure independent of any single provider, while allowing local models, open-source models, optional cloud providers, and future Load-hosted models.

This must be split into two build areas:

1. Load Main:
X-AI-CORE: Load AI Core and Model Independence Layer

2. LoadStudio:
X-STUDIO-AI: Load Creation Engine for AI Production

Do not build the full creative AI studio inside Load Main.
Do not build the AI creation engine inside LoadPlay.
Do not make any outside provider a hard dependency.
Do not hard-code API keys.
Do not mark generated output complete unless a real file/blob/URL exists.
Do not mark model connector READY unless a real test succeeds.

============================================================
PART 1: LOAD MAIN X-AI-CORE
============================================================

Build Load Main’s shared AI infrastructure layer.

Required Load Main screens:
- Load AI Core
- AI Core Settings
- Model Connectors
- Provider Status
- Prompt-only Fallback
- Project Memory
- Rights & Safety
- AI Diagnostics
- Export AI Report

Required modules:
- ai-core.js
- provider-router.js
- model-registry.js
- model-capabilities.js
- local-model-connector.js
- open-source-connector.js
- cloud-provider-connector.js
- prompt-only-connector.js
- project-memory.js
- output-proof.js
- rights-writer.js
- safety-ai-bridge.js
- ai-diagnostics.js
- ai-report-exporter.js

If the file structure differs, adapt to the existing project but keep these modules logically separated.

X-AI-CORE requirements:

1. Add provider/model routing independent of any single external API.
2. Support provider types: local, open-source, cloud-optional, load-hosted-future, prompt-only.
3. Support model capability detection for text, image, video, audio, voice, embeddings, safety, and document parsing.
4. Add provider statuses: Not configured, Ready, Failed, Rate limited, Unsupported request, Returned no file, Offline, Local server unavailable, Needs user setup.
5. Add fallback routing: local model where available, open-source connector, optional cloud provider, prompt-only fallback.
6. Keep all optional cloud providers off by default.
7. Add connector placeholders for local LLM server, ComfyUI, Stable Diffusion workflows, Piper, Kokoro TTS, FFmpeg, and future Load-hosted model server.
8. Add output proof rules.
9. Add project memory files.
10. Add rights metadata writer.
11. Add safety scanner integration.
12. Add AI diagnostic tests for each connector.
13. Add exportable AI diagnostic report.
14. Add prompt-only mode.
15. Add user-facing provider truth.

============================================================
PART 2: LOADSTUDIO X-STUDIO-AI
============================================================

Build LoadStudio’s creative AI production engine using Load Main’s X-AI-CORE.

Required LoadStudio screens:
- Load Creation Engine
- AI Scene Builder
- Book-to-Cinema
- Script-to-Shot
- Character Bible
- Style Bible
- Voice Bible
- Wardrobe Continuity
- Prompt Studio
- Generation Queue
- Output Review
- Continuity Check
- Export to LoadStudio Package

Required modules:
- creation-engine.js
- book-to-cinema.js
- script-to-shot.js
- scene-builder.js
- character-bible.js
- style-bible.js
- voice-bible.js
- wardrobe-bible.js
- prompt-studio.js
- generation-queue.js
- output-review.js
- continuity-checker.js
- export-loadstudio-package.js

X-STUDIO-AI requirements:
1. Add AI Scene Builder.
2. Add Book-to-Cinema workflow.
3. Add Script-to-Shot workflow.
4. Add Character Bible generator.
5. Add Style Bible generator.
6. Add Voice Bible generator.
7. Add Wardrobe Continuity tracker.
8. Add Prompt Studio.
9. Add Generation Queue.
10. Add Output Review.
11. Add Character Consistency checker.
12. Add Scene Consistency checker.
13. Add Continuity Check.
14. Attach generated assets to scenes.json.
15. Attach generated character data to characters.json.
16. Attach rights data to rights.json.
17. Create style-bible.json, voice-bible.json, wardrobe-bible.json, prompt-log.json, generation-report.json, continuity-report.json, model-routing.json, and asset-declarations.json.
18. Export AI-built projects as .loadstudio.zip and .cinepwa.zip.
19. Reopen and edit AI-built projects inside LoadStudio.
20. Use Load Main’s X-AI-CORE router.
21. Always allow prompt-only fallback if generation fails.
22. Failed generation must return failure reason, provider attempted, prompt used, and next recommended action.
23. No generated image/audio/video success message unless real file/blob/URL exists.

============================================================
PART 3: EXPORT PACKAGE REQUIREMENTS
============================================================

Exported AI-built projects must include the existing LoadStudio package structure plus AI files.

Exported packages must pass the existing Load Main LoadStudio validator.

============================================================
PART 4: UI PRINCIPLE
============================================================

Do not make this feel like a generic chatbox.

The UI should follow this production pipeline:

Input → Plan → Generate → Review → Attach → Validate → Export

Main sections:
1. Source Material
2. Project Plan
3. Characters
4. Scenes
5. Prompts
6. Generation Queue
7. Outputs
8. Continuity
9. Rights & Safety
10. Export

============================================================
PART 5: ACCEPTANCE CRITERIA
============================================================

The AI system is not complete unless all acceptance criteria in the master plan are met.

============================================================
PART 6: FINAL REPORT REQUIRED
============================================================

When complete, provide:
1. Exact files changed.
2. Exact files added.
3. Exact files to upload.
4. Confirmation that only necessary files were changed.
5. New screens added.
6. New modules added.
7. Connector registry status.
8. Provider routing behavior.
9. Prompt-only fallback proof.
10. Output proof rules proof.
11. Rights metadata proof.
12. Safety integration proof.
13. LoadStudio workflow proof.
14. Export package proof.
15. Validator pass/fail results.
16. Rows that are VERIFIED.
17. Rows that are READY FOR USER VERIFICATION.
18. Rows that are NOT DONE.
19. Known limitations.
20. Next recommended build step.

Do not mark anything complete without a visible test or code-level proof.
```

---

# 17. Final Recommendation

Do not give this to Claude as part of the small v17g10 patch. It is too large and will cause drift.

Use it after:

```text
Load Main v17g10 home-page handoff shortcut row is complete.
```

Then this becomes the next major roadmap build.
