# Load AI: Glam-Style Image System Research and Developer Plan

Prepared for: LaPamela Avant Bond  
Project: Load AI Image Editor  
Purpose: Map current providers, identify real image editing options, and define a precise architecture for Glam AI style chat, image editing, character consistency, and image-to-video.

## Executive Summary

Load is close to a useful AI image studio, but the current failure point is not the prompt. The core issue is routing. Image generation, image editing, image understanding, prompt rewriting, and image-to-video must be treated as separate task classes. Text-only models must never receive image generation or image editing jobs.

Glam AI style behavior comes from five layers working together:

1. Chat instruction understanding.
2. Task classification.
3. Provider capability routing.
4. True image edit support using image input, mask input, and image output.
5. Output verification before calling anything a success.

The most important next fix for Load is not adding more random providers. The priority is locking the provider routing and adding a browser-based mask/select-area editor so that Load can send sourceImage + mask + prompt to Gemini, Hugging Face, or another true edit-capable provider.

## Part 1: Map of Current Providers and What They Can Actually Do

The current provider chain appears to include several AI providers. They should be divided by role, not treated equally.

### A. Text and Reasoning Providers

These providers should be used for prompt rewriting, task classification, JSON routing, error interpretation, and chat. They should not directly handle image generation or image editing unless the specific model supports image output.

| Provider or Model | Correct Use | Do Not Use For | Notes |
|---|---|---|---|
| HF Mistral | Prompt rewrite, classification, chat | Image generation, image editing | Mistral is text-only in your current setup. It must be blocked from image tasks. |
| Groq | Fast routing, prompt cleanup, JSON classification | Image output | Groq is useful as the brain/router, not the image engine. |
| Puter text models | Chat, lightweight analysis, prompt rewrite | Real inpainting unless actual image output exists | Use only if the selected model returns images. |

### B. Image Generation Providers

These can make images from text, but they are not automatically real editors.

| Provider | Text-to-Image | Image-to-Image | Inpainting | Good For | Risk |
|---|---:|---:|---:|---|---|
| Pollinations | Yes | Limited or uncertain | No reliable true inpainting | Free quick generation | Weak object insertion and identity consistency. |
| AI Horde | Yes | Worker-dependent | Worker-dependent | Free community fallback | Quality and model support vary by worker. |
| DeepAI | Yes or limited | Limited | Usually weak | Simple generation fallback | Not reliable for precision edits. |
| Together AI | Model-dependent | Model-dependent | Model-dependent | Optional free-credit testing | Do not depend on it as permanent free infrastructure. |
| Cloudflare Workers AI | Model-dependent | Model-dependent | Model-dependent | Useful free-tier option | Must check selected model capability before use. |
| Gemini | Yes depending on model | Image edit depending on model/access | Possible depending on current API/model | Strong multimodal option | Must verify endpoint and output type. |
| Hugging Face | Yes depending on model | Yes with correct model | Yes with correct model | Best flexible route if model/endpoint is correct | Key alone is not enough. Model routing must be correct. |

### C. Frontend Editor Tools, Not AI Providers

These should not be added to the 12 AI providers. Add them under Editor Tools or Mask Tools.

| Tool | Free/Open Source | Runs on iPad Browser | Glam-Style Use |
|---|---:|---:|---|
| Canvas API | Yes, browser-native | Yes | Mask painting, erase, crop, image export. |
| Fabric.js | Yes | Yes | Layers, selectable objects, mask brush, image workspace. |
| Konva.js | Yes | Yes | Drag/drop, resize, rotate, layer editing. |
| Cropper.js | Yes | Yes | Crop, zoom, rotate, export selected area. |
| Filerobot Image Editor | Open-source | Yes | Crop, annotate, filters, resize, simple editor UX. |

Important: These tools do not perform AI editing by themselves. Their job is to create the sourceImage + mask + prompt package for a real image-edit model.

## Part 2: Exact Hugging Face Direction

### What went wrong with Hugging Face

The Hugging Face key is not the full solution. If Load has a valid Hugging Face key but routes image tasks to a text-only model like Mistral, the image task will fail. The router must check the selected model before every call.

A Hugging Face fine-grained token with Inference Provider permission is correct for provider calls, but it does not make every model an image editor. Hugging Face supports many model types, including text-only models and image models. Load must verify the model task type before using it.

### Hugging Face models and workflows to consider

#### 1. Stable Diffusion Inpainting

Use when the task is: add object, remove object, replace object, change part of image.

Hugging Face Diffusers documentation explains that inpainting replaces or edits specific areas of an image using a mask. White pixels are filled by the prompt while black pixels are preserved. Source: https://huggingface.co/docs/diffusers/using-diffusers/inpaint

Candidate model:
- stable-diffusion-v1-5/stable-diffusion-inpainting
- diffusers/stable-diffusion-xl-1.0-inpainting-0.1

Use only when payload includes:
- source image
- mask image
- prompt
- optional negative prompt

#### 2. SDXL Inpainting

Use when the task needs better quality and more modern output.

Candidate model:
- diffusers/stable-diffusion-xl-1.0-inpainting-0.1

Best for:
- adding a bird
- adding a person
- changing background section
- removing objects

#### 3. Qwen-Image / Qwen-Image-Edit

Qwen-Image is described as a powerful image generation foundation model capable of complex text rendering and precise image editing. Source: https://github.com/QwenLM/Qwen-Image

Qwen-Image-Edit is described by Qwen as an image editing version that uses visual semantic control and visual appearance control. Source: https://qwenlm.github.io/blog/qwen-image-edit/

Best for future planning:
- instruction-based editing
- preserving identity
- text editing within images
- meme/title/poster style edits

Caution:
- It may require specific hosting, model availability, or non-iPad backend.
- Do not assume it is available through your current Hugging Face key unless the endpoint confirms it.

#### 4. Step1X-Edit

Step1X-Edit is an open-source image editing model designed for general instruction-based image editing. The project says it aims to provide performance comparable to closed-source models such as GPT-4o and Gemini 2 Flash. Sources: https://github.com/stepfun-ai/Step1X-Edit and https://step1x-edit.github.io/

Best for future planning:
- Glam AI Chat style edits
- natural language editing
- add wings, add necklace, change clothes, remove/add objects

Caution:
- Not an iPad-only GitHub Pages solution.
- Likely needs hosted inference, a GPU backend, or integration through a platform that hosts it.

#### 5. FLUX Kontext

FLUX.1 Kontext is described by available providers as an instruction-based image editing model that can edit existing images using text or image context. Some hosted providers describe it as image-to-image text editing. Sources: https://wavespeed.ai/models/wavespeed-ai/flux-kontext-dev and https://genimg.ai/flux-kontext

Best for future planning:
- instruction-based edits
- style transfer
- character/context preservation
- prompt-based changes to existing images

Caution:
- Often accessed through hosted APIs, not always free or open unlimited.
- Add only as optional provider if free/free-credit access is available.

## Part 3: Provider Capability Locking for Load

### Required provider capability flags

Every provider/model in Load should be stored with these flags:

```json
{
  "providerName": "string",
  "modelName": "string",
  "enabled": true,
  "requiresKey": true,
  "keyPresent": false,
  "textOnly": false,
  "canRewritePrompt": false,
  "canClassifyTask": false,
  "canReadImage": false,
  "canGenerateImage": false,
  "canEditImage": false,
  "canInpaint": false,
  "canUseMask": false,
  "canReturnImageUrl": false,
  "canReturnBlob": false,
  "canReturnVideo": false,
  "supportsSeed": false,
  "freeStatus": "free | free-tier | paid | unknown"
}
```

### Routing rules

Use this logic before every provider call:

```text
IF taskType = chat or prompt_rewrite:
    allow text models

IF taskType = image_generate:
    require canGenerateImage = true
    require output image URL, blob, or file
    skip text-only models

IF taskType = image_edit:
    require sourceImage
    require canEditImage = true
    require image output
    skip text-only models

IF taskType = add_object, add_person, remove_object, change_background:
    require sourceImage
    require mask or selected placement area
    require canInpaint = true OR canUseMask = true
    skip all pure text-to-image providers

IF taskType = image_to_video:
    require sourceImage
    require canReturnVideo = true
    skip image-only providers
```

### What Load must stop doing

Load must stop these behaviors:

- Do not send image edits to HF Mistral.
- Do not treat prompt refinement as editing.
- Do not reuse old SD_PROMPT as the main edit method.
- Do not return unchanged image as success.
- Do not return text, JSON, markdown, or explanation as image success.
- Do not keep spinning if provider fails.

### Required debug display

Add a compact debug line for every request:

```text
taskType | provider | model | textOnly | canGenerateImage | canEditImage | canInpaint | maskPresent | sourceImagePresent | outputType | skipped | timedOut
```

## Part 4: Glam AI Clone Architecture for Load

### Layer 1: Chat Input

User types natural language:

- add a bird
- remove the car
- make her outfit red
- turn this into a short video
- animate the hair blowing
- keep editing this same image

### Layer 2: Task Classifier

The classifier converts natural language into a structured task.

```json
{
  "taskType": "ADD_OBJECT",
  "object": "bird",
  "targetArea": "sky or branch area",
  "requiresSourceImage": true,
  "requiresMask": true,
  "requiresInpainting": true,
  "preserveCharacter": true,
  "preserveScene": true
}
```

### Layer 3: Prompt Builder

For add-object tasks:

```text
Add one small bird to the selected area. Match the original image lighting, camera angle, depth of field, color, and style. Preserve all existing objects, subjects, background, and composition. Do not blur, fade, crop, or regenerate the whole image.
```

Negative prompt:

```text
blurry, washed out, faded, different scene, changed composition, changed main subject, distorted object, extra limbs, duplicate subject, low quality
```

### Layer 4: Mask and Select-Area Editor

This is the missing Glam-style layer that can run on iPad.

Use Canvas API or Fabric.js first.

Required features:

- Paint mask.
- Erase/refine mask.
- Select region.
- Crop region.
- Export source image as PNG/base64.
- Export mask as PNG/base64.
- Show before/after.
- Add reset mask button.

This does not require a server. It runs inside the PWA.

### Layer 5: Provider Router

Provider router receives:

```json
{
  "taskType": "ADD_OBJECT",
  "sourceImage": "base64 or blob",
  "maskImage": "base64 or blob",
  "prompt": "edit prompt",
  "negativePrompt": "negative prompt",
  "consistencyMode": "strict"
}
```

It then selects the first provider that can actually handle the task.

### Layer 6: Output Verifier

The verifier must check:

- Did provider return image URL, blob, or file?
- Did output change compared to input?
- Is the output washed out or blurry?
- Did the requested object appear?
- Was the original image preserved?

If failure:

- mark provider failed
- try next provider
- do not call it success

### Layer 7: Image-to-Video

Image-to-video must be a separate task type.

Correct flow:

```text
sourceImage + motion instruction + duration + style + provider with video output
```

Do not send image-to-video jobs to image-only providers.

Basic Load image-to-video features:

- Animate image with camera movement.
- Add zoom or parallax.
- Add subtle motion.
- Turn image into 5 to 10 second clip.
- Preserve character identity.
- Export video or return external prompt if provider unavailable.

Provider capability flags needed:

```json
{
  "canImageToVideo": true,
  "canReturnVideo": true,
  "maxDurationSeconds": 5,
  "requiresKey": true,
  "freeStatus": "free-tier"
}
```

If no image-to-video provider is available, return external prompt for Runway, Kling, Pika, Luma, Wan, or another tool instead of pretending success.

## Part 5: Open-Source and Free Tools Worth Tracking

### Practical now for iPad PWA

These are not AI providers, but they are essential.

| Tool | Use |
|---|---|
| Canvas API | Basic mask drawing, erase, export. |
| Fabric.js | Most useful for Load: layers, selection, masks, objects. |
| Konva.js | Strong for object manipulation and touch-friendly editing. |
| Cropper.js | Clean crop and export. |
| Filerobot Image Editor | Fast editor UI for crop, annotation, filters. |

### Practical with API or cloud route

| Tool or Model | Use | Constraint |
|---|---|---|
| Hugging Face Stable Diffusion Inpainting | Real mask-based edits | Must use correct model and endpoint. |
| Hugging Face SDXL Inpainting | Better inpainting quality | Must verify availability. |
| Gemini image editing | Strong multimodal editing when enabled | Must verify model and endpoint. |
| AI Horde | Free community fallback | Quality varies. |
| Cloudflare Workers AI | Free-tier routing option | Model-dependent. |
| SiliconFlow | Optional provider | Free/free-credit status may change. |

### Advanced open-source, not iPad-only

| Tool or Model | Why it matters | Constraint |
|---|---|---|
| ComfyUI | Best open workflow engine | Needs laptop/server/GPU. |
| Automatic1111 | Stable Diffusion web UI and API | Needs laptop/server/GPU. |
| Fooocus | Easier Stable Diffusion route | Needs laptop/server/GPU. |
| InvokeAI | Polished creative tool | Needs laptop/server/GPU. |
| Step1X-Edit | Instruction-based editing | Needs hosting/backend/GPU. |
| Qwen-Image-Edit | Strong semantic/appearance editing | Needs hosted inference/backend. |
| FLUX Kontext | Instruction-based image editing | Often hosted API/free-credit, not guaranteed free forever. |

## Part 6: Exact Prompt for Claude to Implement This Safely

Use this prompt:

```text
Implement Glam-style routing for Load AI without rebuilding the app.

Do only these steps:

1. Add provider capability flags.
2. Block text-only models from image tasks.
3. Add task classifier:
   - chat
   - prompt rewrite
   - image generate
   - image edit
   - add object
   - add person
   - remove object
   - change background
   - image to video

4. Add Editor Tools section separate from AI Providers:
   - Canvas API or Fabric.js for manual mask painting
   - erase/refine mask
   - crop/select region
   - export sourceImage + mask + prompt

5. Route image edits only to providers that support:
   - source image input
   - image output
   - img2img or inpainting

6. Route image-to-video only to providers that support video output.

7. If no capable provider exists:
   - do not fake success
   - return external prompt for ComfyUI, Stable Diffusion, Runway, Kling, Pika, or Luma.

8. Add debug line:
   taskType | provider | model | canEdit | canInpaint | maskPresent | outputType | skipped | timedOut

9. Add timeout and finally{} cleanup so the app never hangs.

Do not change existing UI except adding mask/select-area controls and debug status.
Do not rewrite working systems.
Minimal patch only.
```

## Part 7: Phase Plan

### Phase 1: Stability

Goal:
- No hangs.
- No text-only models used for image jobs.
- Clear provider diagnostics.

Build:
- Key diagnostic.
- Provider capability registry.
- Timeout and fallback.

### Phase 2: Real Editing Foundation

Goal:
- Add-object and remove-object stop pretending.

Build:
- Canvas or Fabric.js mask tool.
- sourceImage + mask + prompt payload.
- Output verifier.

### Phase 3: Character Consistency

Goal:
- Same person, same outfit, same style.

Build:
- Character profile memory.
- Reference image lock.
- Seed reuse if supported.
- Identity verification.

### Phase 4: Image-to-Video

Goal:
- Turn still images into short clips.

Build:
- Separate image-to-video task type.
- Video provider capability flags.
- Export prompt if provider unavailable.

### Phase 5: Advanced Provider Expansion

Goal:
- Add future open-source edit models when accessible.

Track:
- Step1X-Edit.
- Qwen-Image-Edit.
- FLUX Kontext.
- Stable Diffusion inpainting through hosted or local backend.

## Part 8: Final Truth for Developer

Load should not pretend every AI provider can do every task.

The correct rule is simple:

```text
Text models think.
Image generation models create from prompts.
Image edit models modify pixels.
Video models animate.
Editor tools create masks and layers.
```

Once these roles are separated, Load stops breaking when keys are added and starts behaving like a real AI studio.

## Sources

1. Hugging Face Diffusers Inpainting Documentation: https://huggingface.co/docs/diffusers/using-diffusers/inpaint
2. Stable Diffusion Inpainting Model: https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-inpainting
3. SDXL Inpainting Model: https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1
4. Step1X-Edit GitHub: https://github.com/stepfun-ai/Step1X-Edit
5. Step1X-Edit Project Page: https://step1x-edit.github.io/
6. Qwen-Image GitHub: https://github.com/QwenLM/Qwen-Image
7. Qwen-Image-Edit Blog: https://qwenlm.github.io/blog/qwen-image-edit/
8. Hugging Face Diffusers GitHub: https://github.com/huggingface/diffusers
9. FLUX Kontext Dev API information: https://wavespeed.ai/models/wavespeed-ai/flux-kontext-dev
10. Filerobot Image Editor GitHub: https://github.com/scaleflex/filerobot-image-editor
11. Fabric.js: https://fabricjs.com/
12. Konva.js editor demo documentation: https://konvajs.org/docs/sandbox/Canvas_Editor.html
